package com.github.potatobill.potatoreminder;

import android.app.Application;

import com.github.potatobill.potatoreminder.data.DataManager;
import java.io.File;
import android.os.Bundle;
import java.util.ArrayList;
import com.github.potatobill.potatoreminder.data.EntryPoint;
import android.graphics.Bitmap;

public class App extends Application {
	public DataManager dm;
	public boolean firstIn;
	public int position;
	public File imagePath;
	
	public Bundle tempEntry;
	public ArrayList<EntryPoint> tempList;
	public Bitmap tempBitmap;
	/*
	public static class TYPE
	{
		public final static int NONE = 0;
		public final static int POINT = 1;
		public final static int NODE = 2;
		public final static int LIST = 3;
		public final static int IMAGE = 4;
		public final static int GROUP = 5;
	}
	
	public static class STATE
	{
		public final static int CREATE = 0;
		public final static int UPDATE = 1;
		public final static int RLEVEL_REMEMBER = 2;
		public final static int RLEVEL_LOW = 3;
		public final static int RLEVEL_FORGOT = 4;
		public final static int HINT = 5;
		public final static int SHOW = 6;
	}
	*/
	
	@Override
	public void onCreate() {
		super.onCreate();
		position = 0;
		firstIn = false;
	}
}
